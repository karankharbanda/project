package com.infy.ekart.service.test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerProductServiceTest {

	// Write testcases here

}
