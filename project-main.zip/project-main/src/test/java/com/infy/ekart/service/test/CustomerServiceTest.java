package com.infy.ekart.service.test;

import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.dto.CustomerDTO;
import com.infy.ekart.entity.Customer;
import com.infy.ekart.exception.EKartException;
import com.infy.ekart.repository.CustomerRepository;
import com.infy.ekart.service.CustomerService;
import com.infy.ekart.service.CustomerServiceImpl;

@SpringBootTest
public class CustomerServiceTest {
	//Write testcases here
	
	@Mock
	private CustomerRepository customerRepository;
	
	@InjectMocks
	CustomerService customerService = new CustomerServiceImpl();
	@Test
	void authenticateCusotmerValidTest() throws EKartException
	{
		Customer customer = new Customer();
		customer.setEmailId("tom@infosys.com");
		customer.setPassword("Tom@123");
		String emailId ="tom@infosys.com";
		String password ="Tom@123";
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));
		CustomerDTO cDTO = customerService.authenticateCustomer(emailId, password);
		Assertions.assertEquals(customer.getEmailId(), cDTO.getEmailId());
	}
	
	@Test
	void authenticateCustomerInvalidTest() throws EKartException
	{
		Customer customer = new Customer();
		customer.setEmailId("tom@infosys.com");
		customer.setPassword("Karan");
		String emailId="tom@infosys.com";
		String password = "Tom@123";
		Mockito.when(customerRepository.findById(Mockito.anyString().toLowerCase())).thenReturn(Optional.of(customer));
		Exception e = Assertions.assertThrows(EKartException.class, ()-> customerService.authenticateCustomer(emailId, password));
		Assertions.assertEquals("CustomerService.INVALID_CREDENTIALS", e.getMessage());
	}
	@Test
	void registerCustomerValidTest() throws EKartException
	{
		Customer customer = new Customer();
		customer.setEmailId("karan@infosys.com");
		customer.setAddress("asdfg");
		customer.setName("Karan");
		customer.setPassword("Karan@123");
		customer.setPhoneNumber("8427257047");
		
		CustomerDTO cDTO = new CustomerDTO();
		cDTO.setEmailId("karan@infosys.com");
		cDTO.setAddress("asdfg");
		cDTO.setName("Karan");
		cDTO.setPassword("Karan@123");
		cDTO.setPhoneNumber("8427257047");
		
		Mockito.when(customerRepository.findById(cDTO.getEmailId())).thenReturn(Optional.empty());
		Mockito.when(customerRepository.findByPhoneNumber(Mockito.anyString())).thenReturn(Optional.empty());
		Mockito.when(customerRepository.save(Mockito.any())).thenReturn(customer);
		Assertions.assertEquals(customer.getEmailId(), customerService.registerNewCustomer(cDTO));
	}
	@Test
	void registerCustomerInvalidTest() throws EKartException
	{
		Customer customer = new Customer();
		customer.setEmailId("karan@infosys.com");
		customer.setAddress("asdfg");
		customer.setName("Karan");
		customer.setPassword("Karan@123");
		customer.setPhoneNumber("8427257047");
		
		CustomerDTO cDTO = new CustomerDTO();
		cDTO.setEmailId("karan@infosys.com");
		cDTO.setAddress("asdfg");
		cDTO.setName("Karan");
		cDTO.setPassword("Karan@123");
		cDTO.setPhoneNumber("8427257047");
		
		Mockito.when(customerRepository.findById(cDTO.getEmailId())).thenReturn(Optional.of(customer));
		Mockito.when(customerRepository.findByPhoneNumber(cDTO.getPhoneNumber())).thenReturn(Optional.empty());
		EKartException e = Assertions.assertThrows(EKartException.class,()->customerService.registerNewCustomer(cDTO));
		Assertions.assertEquals("CustomerService.EMAIL_ID_ALREADY_IN_USE",e.getMessage());
	}
	@Test
	void registerCustomerInvalidTestTwo() throws EKartException
	{
		Customer customer = new Customer();
		customer.setEmailId("karan@infosys.com");
		customer.setAddress("asdfg");
		customer.setName("Karan");
		customer.setPassword("Karan@123");
		customer.setPhoneNumber("8427257047");
		
		CustomerDTO cDTO = new CustomerDTO();
		cDTO.setEmailId("karan@infosys.com");
		cDTO.setAddress("asdfg");
		cDTO.setName("Karan");
		cDTO.setPassword("Karan@123");
		cDTO.setPhoneNumber("8427257047");
		
		Mockito.when(customerRepository.findById(cDTO.getEmailId())).thenReturn(Optional.empty());
		Mockito.when(customerRepository.findByPhoneNumber(cDTO.getPhoneNumber())).thenReturn(Optional.of(customer));
		EKartException e = Assertions.assertThrows(EKartException.class,()->customerService.registerNewCustomer(cDTO));
		Assertions.assertEquals("CustomerService.PHONE_NUMBER_ALREADY_IN_USE", e.getMessage());
	}
	@Test
	void deleteShippingAddressValidTest() throws EKartException
	{
		Customer customer = new Customer();
		customer.setEmailId("nick@infosys.com");
		customer.setAddress("asdfg");
		customer.setName("Karan");
		customer.setPassword("Karan@123");
		customer.setPhoneNumber("8427257047");
		
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));
		customerService.deleteShippingAddress(customer.getEmailId());
		Assertions.assertNull(customer.getAddress());
	}
	
	
	@Test 
	void deleteShippingAddressInvalidTest() throws EKartException
	{
		Customer customer = new Customer();
		customer.setEmailId("nick@infosys.com");
		customer.setAddress("asdfg");
		customer.setName("Karan");
		customer.setPassword("Karan@123");
		customer.setPhoneNumber("8427257047");
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException e = Assertions.assertThrows(EKartException.class, ()-> customerService.deleteShippingAddress(customer.getEmailId()));
		Assertions.assertEquals("CustomerService.CUSTOMER_NOT_FOUND", e.getMessage());
	}
	@Test
	void updateShippingAddressValidTest() throws EKartException
	{
		Customer customer = new Customer();
		customer.setEmailId("nick@infosys.com");
		customer.setAddress("asdfg");
		customer.setName("Karan");
		customer.setPassword("Karan@123");
		customer.setPhoneNumber("8427257047");
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));
		customerService.updateShippingAddress(customer.getEmailId(), "ABC");
		Assertions.assertEquals("ABC", customer.getAddress());
	}
	
	@Test 
	void updateShippingAddressInvalidTest() throws EKartException
	{
		Customer customer = new Customer();
		customer.setEmailId("nick@infosys.com");
		customer.setAddress("asdfg");
		customer.setName("Karan");
		customer.setPassword("Karan@123");
		customer.setPhoneNumber("8427257047");
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.empty());
		EKartException e = Assertions.assertThrows(EKartException.class, ()-> customerService.updateShippingAddress(customer.getEmailId(), "ABC"));
		Assertions.assertEquals("CustomerService.CUSTOMER_NOT_FOUND", e.getMessage());
	}
	
	@Test
	void getCustomerByEmailIdValidTest() throws EKartException
	{
		Customer customer = new Customer();
		customer.setEmailId("karan@infosys.com");
		customer.setAddress("asdfg");
		customer.setName("Karan");
		customer.setPassword("Karan@123");
		customer.setPhoneNumber("8427257047");
		
		CustomerDTO cDTO = new CustomerDTO();
		cDTO.setEmailId("karan@infosys.com");
		cDTO.setAddress("asdfg");
		cDTO.setName("Karan");
		cDTO.setPassword("Karan@123");
		cDTO.setPhoneNumber("8427257047");
		
		Mockito.when(customerRepository.findByEmailId(Mockito.anyString())).thenReturn(customer);
		Assertions.assertEquals(cDTO.getEmailId(), customerService.getCustomerByEmailId(customer.getEmailId()).getEmailId());
	}
	
	@Test
	void getCustomerByEmailIdInvalidTest() throws EKartException
	{
		Customer customer = new Customer();
		customer.setEmailId("karan@infosys.com");
		customer.setAddress("asdfg");
		customer.setName("Karan");
		customer.setPassword("Karan@123");
		customer.setPhoneNumber("8427257047");
		
		Mockito.when(customerRepository.findById(Mockito.anyString())).thenReturn(Optional.of(customer));
		EKartException e = Assertions.assertThrows(EKartException.class,()->customerService.getCustomerByEmailId(customer.getEmailId()));
		Assertions.assertEquals("CustomerService.CUSTOMER_NOT_FOUND", e.getMessage());
	}
}
