package com.infy.ekart.service.test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class CustomerOrderServiceTest {
	//Write testcases here
}
